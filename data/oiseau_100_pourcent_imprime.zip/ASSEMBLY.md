# ASSEMBLY GUIDE — Bird

Automate mécanique à 1 came(s) — 19 pièces imprimées

## Outils nécessaires

- Pince coupante / lime (nettoyage supports)
- Colle cyanoacrylate (optionnel)

## Matériel (BOM)

| Pièce | Qté | Source |
|---|---|---|
| Super Lube 21030 (silicone grease) | 1 | Optionnel — améliore la fluidité |

Pièces imprimées: **19**

## Étape 1 — Châssis

1. Poser la **base_plate** sur une surface plane.
2. Vérifier la planéité (pas de warping).
3. Emboîter **wall_left** et **wall_right** sur la base (snap-fit).
4. Monter le **camshaft_bracket** entre les murs.

> ✅ **Vérif**: le châssis doit être rigide, pas de jeu latéral.

## Étape 2 — Arbre principal

1. Insérer l'arbre cannelé (Ø6mm, D-flat) dans les paliers du châssis (bore Ø6.7mm).
2. Le chanfrein d'entrée (0.5mm @ 45°) guide l'insertion.
3. L'arbre doit **tourner librement** — aucun point dur.
4. Clipser un **collier imprimé** sur l'arbre pour le retenir axialement.

> ✅ **Vérif**: rotation manuelle fluide, pas de frottement.

## Étape 3 — Cames (1)

1. Glisser **cam_neck** sur l'arbre (D-flat empêche la rotation).
2. Clipser un **collier imprimé** entre chaque came pour le maintien axial.
3. Vérifier que l'arbre tourne toujours librement.

> ✅ **Vérif**: chaque came est solidaire de l'arbre, pas de glissement.

## Étape 4 — Suiveurs & ressorts

1. Installer les **1 guide(s) de suiveur** sur le châssis.
2. Insérer les tiges de suiveur dans les glissières (jeu 0.3mm).
3. Positionner les ressorts de rappel (si présents).
4. Ajuster la précharge: le suiveur doit toucher la came avec un contact léger permanent.

> ✅ **Vérif**: le suiveur monte/descend sans gripper. Le ressort maintient le contact.

## Étape 5 — Figurine (9 pièces)

1. Assembler les pièces de la figurine entre elles (snap-fit, clearance 0.3mm).
2. Fixer la figurine sur le plateau du suiveur.
3. Ne pas forcer la déflexion du snap-fit (max 15°).
4. Vérifier que la figurine bouge librement avec le suiveur.

> ✅ **Vérif**: la figurine suit le mouvement sans résistance.

## Étape 6 — Manivelle

1. Emboîter la **manivelle** (crank_handle) sur l'extrémité de l'arbre.
2. S'assurer que la manivelle est bien solidaire (D-flat).
3. Tourner — le mouvement doit être fluide et régulier.

> ✅ **Vérif**: rotation complète sans point dur.

## Étape 7 — Finitions

1. Vérifier que tous les snap-fits sont bien enclenchés.
2. Vérifier qu'aucune pièce ne dépasse dans la zone mobile.
3. Appliquer de la graisse silicone (optionnel) sur l'arbre et les paliers.

## Test final

1. Tourner la **manivelle** lentement. Le mécanisme doit être fluide sur 360°.
2. Vérifier l'absence de collision interne.
3. Confirmer que le timing correspond au diagramme.

## Dépannage

| Problème | Cause probable | Solution |
|---|---|---|
| Arbre ne tourne pas | Bore trop serré | Limer légèrement le trou (lime ronde) |
| Came glisse sur l'arbre | D-flat mal orienté | Réimprimer came à 90° |
| Snap-fit casse | Déflexion >15° | Réimprimer + chauffer légèrement |
| Moteur force | Engrenage mal aligné | Réajuster position pignon |
| Vibrations | Arbre mal centré | Vérifier colliers, ajouter graisse silicone |
| Figurine tombe | Snap-fit trop lâche | Colle cyanoacrylate |