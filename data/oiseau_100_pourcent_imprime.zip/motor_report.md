# Motor Report — Bird

- **feasible**: True
- **peak_torque_mNm**: 9.8
- **max_safe_torque_mNm**: 90.0
- **margin_percent**: 89.2
- **recommendation**: OK ✓
