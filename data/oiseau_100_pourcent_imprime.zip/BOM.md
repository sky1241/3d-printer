# BOM — Bird

| Pièce | Qté | Source |
|---|---|---|
| Super Lube 21030 (silicone grease) | 1 | Optionnel — améliore la fluidité |

Pièces imprimées: 19
