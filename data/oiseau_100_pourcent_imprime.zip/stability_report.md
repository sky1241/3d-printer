# Stability Report — Bird

✓ STABLE — masse totale: 87.9g
  CoG: (0.8, -1.2, 12.4)mm
  Hauteur CoG: 12.4mm (14% de la hauteur)
  Marge au bord: 28.8mm

## Part Masses

| Part | Mass (g) |
|---|---|
| motor | 30.0 |
| hardware | 16.8 |
| base_plate | 15.0 |
| cam_neck | 7.7 |
| wall_left | 4.3 |
| wall_right | 4.3 |
| camshaft_bracket | 3.3 |
| shaft_steel | 1.9 |
| crank_handle | 1.4 |
| follower_guide_0 | 0.7 |
| fig_body | 0.7 |
| camshaft | 0.7 |
| fig_head | 0.2 |
| collar_0 | 0.2 |
| collar_1 | 0.2 |
| fig_leg_0 | 0.1 |
| fig_leg_1 | 0.1 |
| fig_neck | 0.1 |
| fig_tail | 0.0 |
| fig_beak | 0.0 |
| fig_eye_left | 0.0 |
| fig_eye_right | 0.0 |

**Total: 87.9g**
