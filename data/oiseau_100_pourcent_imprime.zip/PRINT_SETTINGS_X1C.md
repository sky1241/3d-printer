# 🖨️ Réglages Impression — 🔴 Premium (~1100€)

**Imprimante**: Bambu Lab X1 Carbon, Prusa Core One
**Filament**: PLA | **Buse**: 0.4mm | **Plateau**: Textured PEI
**Prix imprimante**: 900-1300€ | **Volume**: 256×256×256mm
**Vitesse max fiable**: 350mm/s | **Accélération**: 20000mm/s²
**Enceinte fermée**: Oui ✅ | **Slicer**: Bambu Studio, PrusaSlicer, OrcaSlicer

> ℹ️ LiDAR/AI first-layer check. Buse acier trempé pour filaments abrasifs (CF). Chambre chauffée ~55°C.

**Pièces**: 19 | **Réglages**: auto-optimisés par rôle mécanique + tier

## Réglages par pièce

| Pièce | Rôle | Layer | Murs | Infill | Pattern | Vitesse | Support | Ironing |
|-------|------|-------|------|--------|---------|---------|---------|---------|
| base_plate | chassis_base | 0.2mm | 3 | 30% | grid | 144mm/s | Tree | — |
| cam_neck | cam | 0.16mm | 4 | 80% | gyroid | 96mm/s | Tree | ✅ |
| camshaft | camshaft | 0.16mm | 5 | 100% | grid | 96mm/s | Tree | — |
| camshaft_bracket | camshaft | 0.16mm | 5 | 100% | grid | 96mm/s | Tree | — |
| collar_0 | unknown | 0.12mm | 3 | 20% | grid | 144mm/s | Tree | — |
| collar_1 | unknown | 0.12mm | 3 | 20% | grid | 144mm/s | Tree | — |
| crank_handle | unknown | 0.2mm | 3 | 20% | grid | 144mm/s | Tree | — |
| fig_beak | fig_detail | 0.06mm | 2 | 15% | grid | 72mm/s | Tree | — |
| fig_body | fig_body | 0.16mm | 2 | 10% | gyroid | 120mm/s | Tree | ✅ |
| fig_eye_left | fig_detail | 0.06mm | 2 | 15% | grid | 72mm/s | Tree | — |
| fig_eye_right | fig_detail | 0.06mm | 2 | 15% | grid | 72mm/s | Tree | — |
| fig_head | fig_head | 0.12mm | 2 | 10% | gyroid | 96mm/s | Tree | — |
| fig_leg_0 | fig_limb | 0.12mm | 2 | 10% | gyroid | 120mm/s | Tree | — |
| fig_leg_1 | fig_limb | 0.12mm | 2 | 10% | gyroid | 120mm/s | Tree | — |
| fig_neck | fig_limb | 0.12mm | 2 | 10% | gyroid | 120mm/s | Tree | — |
| fig_tail | fig_wing | 0.12mm | 2 | 10% | grid | 120mm/s | Tree | — |
| follower_guide_0 | follower | 0.16mm | 4 | 70% | gyroid | 96mm/s | Tree | — |
| wall_left | chassis_wall | 0.2mm | 3 | 25% | grid | 180mm/s | Tree | — |
| wall_right | chassis_wall | 0.2mm | 3 | 25% | grid | 180mm/s | Tree | — |

## Ordre d'impression recommandé

### 1️⃣ MÉCANIQUE — Lent, haute qualité — cames, arbre, followers
- `cam_neck` — 80% gyroid, 4 murs, 0.16mm, 96mm/s ⚠ Profil came à plat, surface contact vers le haut
- `camshaft` — 100% grid, 5 murs, 0.16mm, 96mm/s ⚠ Axe horizontal à plat (longueur sur X/Y)
- `camshaft_bracket` — 100% grid, 5 murs, 0.16mm, 96mm/s ⚠ Axe horizontal à plat (longueur sur X/Y)
- `follower_guide_0` — 70% gyroid, 4 murs, 0.16mm, 96mm/s ⚠ Tige debout — layers en compression axiale

### 2️⃣ STRUCTURE — Normal — châssis, supports, motor mount
- `base_plate` — 30% grid, 3 murs, 0.2mm, 144mm/s ⚠ Face large vers le bas
- `wall_left` — 25% grid, 3 murs, 0.2mm, 180mm/s ⚠ Debout — layers ⊥ à la charge pour max rigidité
- `wall_right` — 25% grid, 3 murs, 0.2mm, 180mm/s ⚠ Debout — layers ⊥ à la charge pour max rigidité

### 3️⃣ FIGURINE — Rapide, basse densité — corps, membres
- `fig_body` — 10% gyroid, 2 murs, 0.16mm, 120mm/s
- `fig_head` — 10% gyroid, 2 murs, 0.12mm, 96mm/s
- `fig_leg_0` — 10% gyroid, 2 murs, 0.12mm, 120mm/s ⚠ Bras/jambe debout pour éviter supports
- `fig_leg_1` — 10% gyroid, 2 murs, 0.12mm, 120mm/s ⚠ Bras/jambe debout pour éviter supports
- `fig_neck` — 10% gyroid, 2 murs, 0.12mm, 120mm/s ⚠ Bras/jambe debout pour éviter supports
- `fig_tail` — 10% grid, 2 murs, 0.12mm, 120mm/s

### 4️⃣ DÉTAILS — Très fin — yeux, bec, oreilles
- `fig_beak` — 15% grid, 2 murs, 0.06mm, 72mm/s
- `fig_eye_left` — 15% grid, 2 murs, 0.06mm, 72mm/s
- `fig_eye_right` — 15% grid, 2 murs, 0.06mm, 72mm/s

## Conseils spécifiques

- **LiDAR**: Vérification auto de la 1ère couche — pas besoin de surveiller.
- **Adaptive layers**: Activer dans le slicer pour les figurines (couches variables auto).
- **Buse acier**: Si utilisation de CF-PLA ou CF-PETG, pas besoin de changer de buse.
- **Chambre chauffée**: Préchauffer 10min pour ABS/PC avant de lancer.
- **Températures**: Buse 220°C / Lit 55°C
- **Conseil**: Utiliser la caméra intégrée pour time-lapse du mécanisme final.

## Post-traitement

- **Ébavurage**: Foret Ø3mm à main pour les trous d'axe
- **Assemblage**: Axes inox Ø3mm + goutte de cyanoacrylate si jeu
- **Lubrification**: Super Lube 21030 (cames) / WD-40 PTFE (axes)