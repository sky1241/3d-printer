# FDM Tolerance Report — PREMIUM
Material: PLA | Precision: ±0.05mm XY, ±0.03mm Z

## Clearances

| Parameter | Value | Resulting Diameter |
|---|---|---|
| Shaft Ø3mm free bore | +0.20mm/side | Ø3.4mm |
| Shaft Ø3mm press-fit | +0.08mm/side | Ø3.2mm |
| Slide clearance | +0.20mm/face | — |
| Snap-fit clearance | +0.20mm | — |

## Shrinkage (PLA)

| Material | Shrinkage |
|---|---|
| PLA | 0.3% |
| PETG | 0.5% |
| ABS | 1.0% |

## Print Limits

| Parameter | Value |
|---|---|
| Min wall thickness | 0.8mm |
| Min feature size | 0.6mm |
| Max overhang (no support) | 75° |
| Hole XY compensation | +0.10mm |

## Comparison (all tiers)

| Parameter | Budget | Medium | Premium |
|---|---|---|---|
| Shaft bore free | Ø3.6 | Ø3.5 | Ø3.4 |
| Slide clearance | 0.30 | 0.25 | 0.20 |
| PLA shrink | 0.5% | 0.4% | 0.3% |
| Min wall | 1.2 | 1.0 | 0.8 |
| Max overhang | 45° | 60° | 75° |
| XY precision | ±0.20 | ±0.10 | ±0.05 |

> ⚠️ Valeurs indicatives — calibrer avec une plaque test sur votre machine.