# 🐦 Oiseau mécanique — 100% imprimé en 3D

## C'est quoi ?
Un petit oiseau qui hoche la tête quand tu tournes la manivelle.
**Zéro quincaillerie, zéro courses, zéro euros.** Tout sort de l'imprimante.

---

## 🖨️ Impression — Bambu Lab X1C

**Filament** : PLA standard (1 seule couleur suffit, ou multi-couleur pour le fun)
**Buse** : 0.4mm (celle par défaut)
**Plateau** : Textured PEI
**Température** : Buse 220°C / Lit 55°C

### Batch 1 — Mécanisme (important = qualité haute)
| Fichier | Layer | Infill | Vitesse | Notes |
|---------|-------|--------|---------|-------|
| `cam_neck.stl` | 0.16mm | 80% gyroid | 96mm/s | **Poser à plat, surface came vers le haut** |
| `camshaft.stl` | 0.16mm | 100% | 96mm/s | L'arbre — poser à l'horizontale |
| `camshaft_bracket.stl` | 0.16mm | 100% | 96mm/s | |
| `crank_handle.stl` | 0.16mm | 80% | 96mm/s | La manivelle |
| `collar_0.stl` | 0.16mm | 100% | 72mm/s | Petit anneau de retenue |
| `collar_1.stl` | 0.16mm | 100% | 72mm/s | Petit anneau de retenue |
| `follower_guide_0.stl` | 0.16mm | 70% gyroid | 96mm/s | Debout |

### Batch 2 — Structure (qualité normale)
| Fichier | Layer | Infill | Vitesse |
|---------|-------|--------|---------|
| `base_plate.stl` | 0.2mm | 30% | 144mm/s |
| `wall_left.stl` | 0.2mm | 25% | 180mm/s |
| `wall_right.stl` | 0.2mm | 25% | 180mm/s |

### Batch 3 — L'oiseau (tout sur le plateau en même temps)
| Fichiers | Layer | Infill | Vitesse |
|----------|-------|--------|---------|
| `fig_body.stl` | 0.16mm | 10% | 120mm/s |
| `fig_head.stl` | 0.12mm | 10% | 96mm/s |
| `fig_neck.stl` | 0.12mm | 10% | 120mm/s |
| `fig_leg_0/1.stl` | 0.12mm | 10% | 120mm/s |
| `fig_beak.stl` | 0.06mm | 15% | 72mm/s |
| `fig_eye_left/right.stl` | 0.06mm | 15% | 72mm/s |

---

## 🔧 Assemblage

1. **Enfiler l'arbre** (`camshaft`) dans `wall_left` → came → `wall_right`
2. **Clipser les colliers** (`collar_0`, `collar_1`) sur l'arbre pour bloquer
3. **Fixer la manivelle** (`crank_handle`) au bout de l'arbre (emboîtement)
4. **Poser le suiveur** (`follower_guide_0`) dans son rail
5. **Assembler l'oiseau** (snap-fit, pas de colle)
6. **Tourner la manivelle** → l'oiseau hoche la tête !

**Optionnel** : une goutte de graisse silicone sur la came pour que ça tourne mieux.

---

## 📐 Infos

- Dimensions : ~80 × 60 × 50 mm
- Poids : ~90g
- 20 pièces imprimées
- Temps d'impression estimé : ~1h30
- Aucun achat nécessaire

Bon print ! 🚀
